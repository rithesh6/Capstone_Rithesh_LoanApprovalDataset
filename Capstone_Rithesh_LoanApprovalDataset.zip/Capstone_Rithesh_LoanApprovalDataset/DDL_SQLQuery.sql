CREATE TABLE LoanData (
    LoanNr_ChkDgt BIGINT PRIMARY KEY, -- Assuming an identifier is a string
    Name VARCHAR(255), -- Borrower name
    City VARCHAR(255), -- Borrower city
    State CHAR(2), -- Borrower state
    Zip INT, -- Borrower zip code
    Bank VARCHAR(255), -- Bank name
    BankState CHAR(2), -- Bank state
    NAICS INT, -- North American industry classification system code
    ApprovalDate DATE, -- Date SBA commitment issued
    ApprovalFY INT, -- Fiscal year of commitment
    Term INT, -- Loan term in months
    NoEmp INT, -- Number of business employees
    NewExist INT, --  1 = Existing business,  2 = New business
    CreateJob INT, -- Number of jobs created
    RetainedJob INT, -- Number of jobs retained
    FranchiseCode INT, -- Franchise code, (00000 or  00001) = No franchise
    UrbanRural INT, --  1 = Urban,  2 = rural,  0 = undefined
    RevLineCr CHAR(1), -- Revolving line of credit: Y = Yes, N = No
    LowDoc CHAR(1), -- LowDoc Loan Program: Y = Yes, N = No
    ChgOffDate DATE, -- The date when a loan is declared to be in default
    DisbursementDate DATE, -- Disbursement date
    DisbursementGross VARCHAR(255), -- Amount disbursed
    BalanceGross VARCHAR(255), -- Gross amount outstanding
    MIS_Status VARCHAR(10), -- Loan status charged off = CHGOFF, Paid in full =PIF
    ChgOffPrinGr VARCHAR(255), -- Charged-off amount
    GrAppv VARCHAR(255), -- Gross amount of loan approved by bank
    SBA_Appv VARCHAR(255) -- SBA�s guaranteed amount of approved loan
);

select * from DIM_State
select * from DIM_Bank_Details

select * from DIM_Loan_Details
where name = 'Rithesh'

CREATE TABLE DIM_State (
    StateID INT PRIMARY KEY,
	State CHAR(2),
    City VARCHAR(255),
    Zip INT
);

CREATE TABLE DIM_Bank_Details (
    BankID INT PRIMARY KEY,
    Bank VARCHAR(255),
    BankState CHAR(2)
);


CREATE TABLE DIM_Loan_Details (
    LoanID INT PRIMARY KEY,
	LoanNr_ChkDgt BIGINT,
    Name VARCHAR(255),
    Term INT,
	UrbanRural INT, --  1 = Urban,  2 = rural,  0 = undefined
    LowDoc CHAR(1), -- LowDoc Loan Program: Y = Yes, N = No
    ChgOffDate DATE,
	ApprovalDate DATE,
	RevLineCr CHAR(1)
);


CREATE TABLE Fact (
    LoanNr_ChkDgt BIGINT PRIMARY KEY,
    LoanID INT FOREIGN KEY REFERENCES DIM_Loan_Details(LoanID),
    StateID INT FOREIGN KEY REFERENCES DIM_State(StateID),
    BankID INT FOREIGN KEY REFERENCES DIM_Bank_Details(BankID),
	DisbursementDate DATE, -- Disbursement date
    DisbursementGross DECIMAL(18,2), -- Amount disbursed
    BalanceGross DECIMAL(18,2), -- Gross amount outstanding
    MIS_Status VARCHAR(10), -- Loan status charged off = CHGOFF, Paid in full =PIF
    ChgOffPrinGr DECIMAL(18,2), -- Charged-off amount
    GrAppv DECIMAL(18,2), -- Gross amount of loan approved by bank
    SBA_Appv DECIMAL(18,2), -- SBA�s guaranteed amount of approved loan
	CreatedDate DATETIME,
	UpdatedDate DATETIME
);



ALTER TABLE DIM_State
ADD CreatedDate DATETIME,UpdatedDate DATETIME;

ALTER TABLE DIM_Bank_Details
ADD CreatedDate DATETIME,UpdatedDate DATETIME;

ALTER TABLE DIM_Loan_Details
ADD CreatedDate DATETIME,UpdatedDate DATETIME;

ALTER TABLE DIM_Loan_Details
ADD ApprovalDate DATE,RevLineCr CHAR(1);

ALTER TABLE Fact
ADD CreatedDate DATETIME,UpdatedDate DATETIME;

delete from LoanData
delete from DIM_State
delete from DIM_Bank_Details
delete from DIM_Loan_Details
delete from Fact


update LoanData 
set City =   'ALCOSTA BLVD. SAN'
where City = 'SOMETHING' 



select month(A.ApprovalDate),sum(F.DisbursementGross) from Fact F
join DIM_Loan_Details A on F.LoanID = A.LoanID
group by month(A.ApprovalDate)
order by month(A.ApprovalDate)




SELECT DISTINCT LoanData.City, LoanData.State, LoanData.Zip 
FROM
 LoanData
where LoanData.City is not NULL 
and LoanData.State is not NULL
order by LoanData.City




select  distinct  LoanData.Bank, LoanData.BankState from LoanData 
where  LoanData.Bank is not NULL
group by  LoanData.Bank, LoanData.BankState 




select  distinct Bank, count(Bank) as b from LoanData 
group by Bank 
order by b DESC,Bank ASC



delete from LoanData
where BankState = 'ZZ'



update LoanData
set BankState = 'ZZ'
where bank = 'JPMORGAN CHASE BANK NATL ASSOC'
and BankState = 'WV'



select * from DIM_Bank_Details 
where bank = 'JPMORGAN CHASE BANK NATL ASSOC'



SELECT DISTINCT LoanData.Bank, LoanData.BankState 
FROM
 LoanData
where  LoanData.Bank is not NULL




select  distinct  LoanData.Bank, LoanData.BankState from LoanData 
where  LoanData.Bank is not NULL
group by  LoanData.Bank, LoanData.BankState



INSERT INTO LoanData (
    LoanNr_ChkDgt,
    Name,
    City,
    State,
    Zip,
    Bank,
    BankState,
    NAICS,
    ApprovalDate,
    ApprovalFY,
    Term,
    NoEmp,
    NewExist,
    CreateJob,
    RetainedJob,
    FranchiseCode,
    UrbanRural,
    RevLineCr,
    LowDoc,
    ChgOffDate,
    DisbursementDate,
    DisbursementGross,
    BalanceGross,
    MIS_Status,
    ChgOffPrinGr,
    GrAppv,
    SBA_Appv
) VALUES (
    1234567899, -- LoanNr_ChkDgt
    'Rithesh', -- Name
    'New York', -- City
    'NY', -- State
    10001, -- Zip
    'Bank of Example', -- Bank
    'NY', -- BankState
    12345, -- NAICS
    '2024-01-01', -- ApprovalDate
    2024, -- ApprovalFY
    12, -- Term
    50, -- NoEmp
    1, -- NewExist
    5, -- CreateJob
    45, -- RetainedJob
    00000, -- FranchiseCode
    1, -- UrbanRural
    'N', -- RevLineCr
    'Y', -- LowDoc
    NULL, -- ChgOffDate
    '2024-01-15', -- DisbursementDate
    50000.00, -- DisbursementGross
    25000.00, -- BalanceGross
    'PIF', -- MIS_Status
    NULL, -- ChgOffPrinGr
    50000.00, -- GrAppv
    25000.00 -- SBA_Appv
);


UPDATE LoanData
SET 
    Name = 'Rithesh',
	RevLineCr = 'Y'
WHERE
    LoanNr_ChkDgt = 1234567890;



SELECT 
	DATEDIFF(DAY, L.ApprovalDate, F.DisbursementDate),
    count(DATEDIFF(DAY, L.ApprovalDate, F.DisbursementDate)) AS DaysToDisbursement
FROM 
    Fact F
JOIN 
    DIM_Loan_Details L ON F.LoanNr_ChkDgt = L.LoanNr_ChkDgt
WHERE 
    L.ApprovalDate IS NOT NULL AND F.DisbursementDate IS NOT NULL
group by 
	DATEDIFF(DAY, L.ApprovalDate, F.DisbursementDate)

order by 
	DaysToDisbursement desc