--1. Total Disbursements by State
--the total disbursements by state, which can give insight into the distribution of loan disbursements across different states.
SELECT 
    S.State, 
    SUM(F.DisbursementGross) AS TotalDisbursements,
    (SUM(F.DisbursementGross) / (SELECT SUM(DisbursementGross) FROM Fact)) * 100 AS DisbursementPercentage
FROM 
    Fact F
JOIN 
    DIM_State S ON F.StateID = S.StateID
WHERE
    S.State IS NOT NULL
GROUP BY 
    S.State
ORDER BY
    TotalDisbursements DESC;


2. Loan Approvals by Bank
This query provides insight into the volume of loan approvals by each bank, 
which can be useful for understanding the distribution of loan approvals across different financial institutions.

SELECT 
    B.Bank, 
    COUNT(F.LoanNr_ChkDgt) AS LoanApprovals
FROM 
    Fact F
JOIN 
    DIM_Bank_Details B ON F.BankID = B.BankID
GROUP BY 
    B.Bank
ORDER BY
	LoanApprovals desc

3. Total Loans by Bank and State
This query combines information from the Fact table with the DIM_Bank_Details and DIM_State tables to show the 
total number of loans issued by each bank in each state.

SELECT 
    B.Bank, 
    S.State, 
    COUNT(F.LoanNr_ChkDgt) AS TotalLoans
FROM 
    Fact F
JOIN 
    DIM_Bank_Details B ON F.BankID = B.BankID
JOIN 
    DIM_State S ON F.StateID = S.StateID
GROUP BY 
    B.Bank, S.State
ORDER BY
	TotalLoans desc

4. Average Loan Term by Urban/Rural
the average loan term for loans categorized as urban and rural, providing insights into the loan terms based on the location of the borrower.

SELECT 
    CASE 
        WHEN L.UrbanRural = 1 THEN 'Urban'
        WHEN L.UrbanRural = 2 THEN 'Rural'
        WHEN L.UrbanRural = 0 THEN 'Undefined'
    END AS UrbanRural,
    AVG(L.Term) AS AverageLoanTerm
FROM 
    Fact F
JOIN 
    DIM_Loan_Details L ON F.LoanNr_ChkDgt = L.LoanNr_ChkDgt
GROUP BY 
    L.UrbanRural;



--5. Loan Status Distribution
--This query shows the distribution of loan statuses, which can help in understanding the overall health of the loans managed by the bank.

SELECT 
    F.MIS_Status, 
    COUNT(F.LoanNr_ChkDgt) AS LoanStatusCount
FROM 
    Fact F
WHERE
	F.MIS_Status is not null
GROUP BY 
    F.MIS_Status;



--6. Risk assessment and decision to approve or review the loan 

SELECT
    F.LoanNr_ChkDgt,
    L.Term,
    L.UrbanRural,
    TRY_CAST(REPLACE(F.GrAppv, '$', '') AS DECIMAL) AS GrAppvDecimal,
    CASE
        WHEN L.Term > 40 THEN 'High Risk'
        WHEN L.UrbanRural = 2 THEN 'Low Risk'
        WHEN TRY_CAST(REPLACE(F.GrAppv, '$', '') AS DECIMAL) > 100000 THEN 'High Risk'
        ELSE 'Medium Risk'
    END AS RiskAssessment,
    CASE
        WHEN L.Term <= 40 AND L.UrbanRural = 1 AND TRY_CAST(REPLACE(F.GrAppv, '$', '') AS DECIMAL) <= 100000 THEN 'Approve'
        ELSE 'Review'
    END AS Decision
FROM
    Fact F
JOIN
    DIM_Loan_Details L ON F.LoanNr_ChkDgt = L.LoanNr_ChkDgt
WHERE
    TRY_CAST(REPLACE(F.GrAppv, '$', '') AS DECIMAL) IS NOT NULL;


--7. number of days it took from the approval of the loan to the actual disbursement of the funds. 
--My hypothesis is that the timing at which the funds were received could have a negative relationship with a business's ability 
--to repay a loan, whereas the longer it took to receive funds, the more difficult it would be to pay off the loan.

--ordered it by difference between the number of loans and the charged off loans that means the days from top to bottom represent 
--the ideal days it took for the business to recieve money to successfully repay the debt and have minimum charged off loans 

--charged off loan is that a lender has written off a loan as a loss.

SELECT 
    DATEDIFF(DAY, D.ApprovalDate, F.DisbursementDate) AS DaysToDisbursement,
    AVG(F.DisbursementGross) AS AverageDisbursementAmount,
	COUNT(F.LoanNr_ChkDgt) AS NumberOfLoans,
    SUM(CASE WHEN F.MIS_Status = 'CHGOFF' THEN 1 ELSE 0 END) AS ChargedOffLoans,
    ((COUNT(F.LoanNr_ChkDgt) - SUM(CASE WHEN F.MIS_Status = 'CHGOFF' THEN 1 ELSE 0 END)) * 100 / COUNT(F.LoanNr_ChkDgt)) AS PercentagePaid
FROM 
    Fact F
JOIN 
    DIM_Loan_Details D ON F.LoanID = D.LoanID
WHERE 
	DATEDIFF(DAY, D.ApprovalDate, F.DisbursementDate) is not null
GROUP BY 
    DATEDIFF(DAY, D.ApprovalDate, F.DisbursementDate)
ORDER BY 
    COUNT(F.LoanNr_ChkDgt)-SUM(CASE WHEN F.MIS_Status = 'CHGOFF' THEN 1 ELSE 0 END) desc

 --8. whether or not the bank servicing the loan was in the same state that the business was located. 
 --My assumption is that it would be more difficult to service a loan for a business in another state 
 --and that this could have a negative impact on a business's ability

SELECT 
    CASE 
        WHEN S.State = B.BankState THEN 'Same State'
        ELSE 'Different State'
    END AS StateComparison,
    COUNT(F.LoanNr_ChkDgt) AS NumberOfLoans,
    AVG(F.DisbursementGross) AS AverageDisbursementAmount,
    SUM(CASE WHEN F.MIS_Status = 'CHGOFF' THEN 1 ELSE 0 END) AS ChargedOffLoans,
    SUM(CASE WHEN F.MIS_Status = 'PIF' THEN 1 ELSE 0 END) AS PaidInFullLoans
FROM 
    Fact F
JOIN 
    DIM_State S ON F.StateID = S.StateID
JOIN 
    DIM_Bank_Details B ON F.BankID = B.BankID
GROUP BY 
    CASE 
        WHEN S.State = B.BankState THEN 'Same State'
        ELSE 'Different State'
    END
ORDER BY 
    StateComparison;

--9. amount of the loan the SBA guaranteed
--the SBA will 'guaranty' a percentage of the loan in the event of a loss. For example if a business took out a 500,000 loan 
--and the SBA guaranteed 50%, if the business was unable to repay 200,000 of the loan the SBA would cover 100,000 of that loss.

SELECT 
    CASE 
        WHEN F.DisbursementGross = 0 THEN NULL 
        ELSE CAST((F.SBA_Appv / F.DisbursementGross) * 100 as INT)
    END AS SBA_GuaranteePercentage,
    COUNT(F.LoanNr_ChkDgt) AS NumberOfLoans,
    SUM(CASE WHEN F.MIS_Status = 'CHGOFF' THEN 1 ELSE 0 END) AS ChargedOffLoans,
    ((COUNT(F.LoanNr_ChkDgt) - SUM(CASE WHEN F.MIS_Status = 'CHGOFF' THEN 1 ELSE 0 END)) * 100 / COUNT(F.LoanNr_ChkDgt)) AS PercentagePaid,
	CAST(AVG(F.SBA_Appv) AS INT)  AS AverageSBA_AppvAmount,
    CAST(AVG(F.DisbursementGross) AS INT) AS AverageDisbursementAmount
FROM 
    Fact F
GROUP BY 
    CASE 
        WHEN F.DisbursementGross = 0 THEN NULL 
        ELSE CAST((F.SBA_Appv / F.DisbursementGross) * 100 as INT)
    END
ORDER BY 
    COUNT(F.LoanNr_ChkDgt)-SUM(CASE WHEN F.MIS_Status = 'CHGOFF' THEN 1 ELSE 0 END) desc,
	PercentagePaid DESC



